<h1 align="center">Welcome to Sorting-Algorithms 👋</h1>
<p>
</p>

> Sorting Algorithms: <br /><br /> - Bubble Sort <br /> - Selection Sort <br /> - Insertion Sort <br /> - Merge Sort <br /> - Quick Sort <br /> - Radix Sort

## Install

```sh
git clone https://github.com/peguimasid/Sorting-Algorithms.git
```

## Author

👤 **Guilhermo Masid**

* Github: [@peguimasid](https://github.com/peguimasid)
* LinkedIn: [@guilhermo-masid-494677b8](https://linkedin.com/in/guilhermo-masid-494677b8)

## Show your support

Give a ⭐️ if this project helped you!
